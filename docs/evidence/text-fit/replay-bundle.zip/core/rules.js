import { measureAction } from "./action-rule.js";
import { measureText } from "./text-rule.js";
export function measureRule(page, rule) {
    return rule.kind === 'text-fit' ? measureText(page, rule) : measureAction(page, rule);
}
